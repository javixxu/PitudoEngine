#define LUA_IMPL
#include "minilua.h"